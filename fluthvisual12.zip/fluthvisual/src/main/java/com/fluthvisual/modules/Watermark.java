package com.fluthvisual.modules;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class Watermark {
    public static boolean enabled = true;

    public static void register() {
        HudRenderCallback.EVENT.register((DrawContext context, float tickDelta) -> {
            if (!enabled) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;

            String text = "Fluth Visual";
            int textWidth = mc.textRenderer.getWidth(text);
            int padding = 4;
            int x = (mc.getWindow().getScaledWidth() / 2) - (textWidth / 2) - padding;
            int y = 4;

            context.fill(x, y, x + textWidth + padding * 2, y + 14, 0xCC1A1A2E);
            context.drawBorder(x, y, textWidth + padding * 2, 14, 0xFF8B5CF6);
            context.drawTextWithShadow(mc.textRenderer, text, x + padding, y + 3, 0xFF8B5CF6);
        });
    }
}