package com.fluthvisual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final String[] CATEGORIES = {"Combat", "Visuals", "Player", "World", "World All"};
    private int selectedCategory = 1;

    private static final String[][] MODULES = {
        { "Target ESP", "Kill Aura", "Reach" },
        { "Custom Sky", "View Model", "Hand Aura", "Block Overlay", "Aspect Ratio", "Watermark" },
        { "Sprint", "No Fall", "Speed" },
        { "X-Ray", "Full Bright", "Time Changer" },
        { "Anti Void", "Auto Tool", "Chest Stealer" }
    };

    private final List<String> enabledModules = new ArrayList<>();

    public ClickGui() {
        super(Text.literal("Fluth Visual"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int panelX = 20;
        int panelY = 40;
        int panelW = 100;
        int panelH = 30 + CATEGORIES.length * 20;

        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xCC1A1A2E);
        context.drawBorder(panelX, panelY, panelW, panelH, 0xFF8B5CF6);
        context.drawTextWithShadow(this.textRenderer, "Fluth Visual", panelX + 8, panelY + 6, 0xFF8B5CF6);

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = panelY + 24 + i * 18;
            boolean selected = (i == selectedCategory);
            int color = selected ? 0xFF8B5CF6 : 0xFFCCCCCC;
            if (selected) {
                context.fill(panelX + 4, y - 2, panelX + panelW - 4, y + 14, 0x558B5CF6);
            }
            context.drawTextWithShadow(this.textRenderer, CATEGORIES[i], panelX + 10, y, color);
        }

        int modX = panelX + panelW + 10;
        int modW = 160;
        int modH = 30 + MODULES[selectedCategory].length * 18;
        context.fill(modX, panelY, modX + modW, panelY + modH, 0xCC1A1A2E);
        context.drawBorder(modX, panelY, modW, modH, 0xFF8B5CF6);
        context.drawTextWithShadow(this.textRenderer, CATEGORIES[selectedCategory], modX + 8, panelY + 6, 0xFF8B5CF6);

        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = panelY + 24 + i * 18;
            boolean on = enabledModules.contains(module);
            int color = on ? 0xFF55FF55 : 0xFFAAAAAA;
            String prefix = on ? "[+] " : "[-] ";
            context.drawTextWithShadow(this.textRenderer, prefix + module, modX + 10, y, color);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelX = 20;
        int panelY = 40;
        int panelW = 100;

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = panelY + 24 + i * 18;
            if (mouseX >= panelX && mouseX <= panelX + panelW && mouseY >= y - 2 && mouseY <= y + 14) {
                selectedCategory = i;
                return true;
            }
        }

        int modX = panelX + panelW + 10;
        int modW = 160;
        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = panelY + 24 + i * 18;
            if (mouseX >= modX && mouseX <= modX + modW && mouseY >= y - 2 && mouseY <= y + 14) {
                if (enabledModules.contains(module)) {
                    enabledModules.remove(module);
                } else {
                    enabledModules.add(module);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}